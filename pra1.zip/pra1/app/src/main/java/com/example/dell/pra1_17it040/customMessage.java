package com.example.dell.pra1_17it040;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class customMessage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.custom_message);
    }
}
